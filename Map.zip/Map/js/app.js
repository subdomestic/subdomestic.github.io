var googleSuccess = function(){
//List of locations
var locations = [{
        name: 'Bolívar Square',
        latitude: 4.5981259,
        longitude: -74.0782322,
        description: 'Main square in downtown. Here you can find the mayor, capitol and the main Cathedral',
        marker: ''
    },
    {
        name: 'Gold Museum',
        latitude: 4.5982801,
        longitude: -74.0772751,
        description: 'Museum that displays the gold used by aborigins in Colombia',
        marker: ''
    },
    {
        name: 'Colombian National Museum',
        latitude: 4.6154977,
        longitude: -74.0704757,
        description: 'Museum that displays the history if the country',
        marker: ''
    },
    {
        name: 'Planetarium of Bogota',
        latitude: 4.6120873,
        longitude: -74.0709737,
        description: 'Astrology musem',
        marker: ''
    },
    {
        name: 'Monserrate Sanctuary',
        latitude: 4.6012648,
        longitude: -74.0671971,
        description: 'One of the main atractions of the city where you can find a church at the top of a mountain',
        marker: ''
    }
];


var MyViewModel = function() {
    var self = this;
    //Create map
    self.map = new google.maps.Map(document.getElementById("map-div"), {
        center: new google.maps.LatLng(4.6063134, -74.0753201),
         zoom: 14,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    //Create an empty array to manipulate places

    self.allLocations = [];
    locations.forEach(function(Item){
        self.allLocations.push(new Place(Item));
    });

    //Create a single infoWindow Object to avoid multiple infowindows open at the same time
     self.infoWindow = new google.maps.InfoWindow();

    //Add a map marker for every location
    self.allLocations.forEach(function(Item){
       var content = '<div class="infoBox text-center row">' + '<h1>' + Item.name + '</h1>' + '<h4>' + Item.description + '</h4>'
                      + "<div id='content'>Wikipedia Articles:</div>" + '</div>';
    //Marker options
       var latLng = new google.maps.LatLng(Item.lat, Item.long);
            var markerOptions = {
                map: self.map,
                position: latLng,
                draggable: false,
                animation: google.maps.Animation.DROP,
                content: content
            };

            Item.marker = new google.maps.Marker(markerOptions);
    //Actions when an element is clicked
            Item.marker.addListener('click', function toggleBounce() {
               self.infoWindow.setContent(Item.marker.content);
               self.infoWindow.open(self.map, Item.marker);
    //Call wikipedia API using ajax
               self.wikiApi();
    //Markers animations
                if (Item.marker.getAnimation() !== null) {
                    Item.marker.setAnimation(null);
                } else {
                    Item.marker.setAnimation(google.maps.Animation.BOUNCE);
                }
                setTimeout(function() {
                    Item.marker.setAnimation(null);
                }, 1400);
            });
    //Call wikipedia API to retrieve articles about every location
            self.wikiApi = function() {
                var $infowindowContent = $('#content');
                var wikiUrl = 'http://en.wikipedia.org/w/api.php?action=opensearch&search=' + Item.name + '&format=json&callback=wikiCallback';
                var wikiRequestTimeout = setTimeout(function() {
                    $windowContent.text("failed to get wikipedia resources");
                }, 8000);

                $.ajax({
                    url: wikiUrl,
                    dataType: "jsonp",
                    //jsonp: "callback",
                    success: function(response) {
                        var articleList = response[1];
                        var i;
                        var articleStr;
                        var url;
                        $infowindowContent.text('');
                        $infowindowContent.append('<h3>Wikipedia Articles:</h3>');
                        for (i = 0; i < articleList.length; i += 1) {
                            articleStr = articleList[i];
                            url = 'http://en.wikipedia.org/wiki/' + articleStr;

                            $infowindowContent.append('<li class="text-center"><a href="' + url + '">' + articleStr + '</a></li>');
                        }
                        clearTimeout(wikiRequestTimeout);
                    }
                });
            };
    });

    //Create an observable array for visible Items on the map
    self.visibleItems = ko.observableArray();
    //All locations are visible in the begining
    self.allLocations.forEach(function(Item){
        self.visibleItems.push(Item);
    });
    //User input
    self.query = ko.observable('');
    //Look for the name of the location in the stored locations. If found the location will remain visible, otherwise it will be hidden
    self.filterLocations = function(){
            var userInput = self.query().toLowerCase();
            self.visibleItems.removeAll();

            // Look for the location name through the stored locations. If found, it remains visible

            self.allLocations.forEach(function(Item) {
                Item.marker.setMap(null);

                if (Item.name.toLowerCase().indexOf(userInput) !== -1) {
                    self.visibleItems.push(Item);
                };
            });

            self.visibleItems().forEach(function(Item) {
                Item.marker.setMap(self.map);
            });
    }

    //Place object to store and manipulare all the locations
    function Place(data){

        this.name = data.name;
        this.lat= data.latitude;
        this.long = data.longitude;
        this.description = data.description;
        this.openWindow = function() {
               self.infoWindow.setContent(this.marker.content);
               self.infoWindow.open(self.map, this.marker);
                self.wikiApi();
                if (this.marker.getAnimation() !== null) {
                    this.marker.setAnimation(null);
                } else {
                    this.marker.setAnimation(google.maps.Animation.DROP);
                }
        // Will be saved after built
        this.marker = null;
    }
    };

};
ko.applyBindings(new MyViewModel);
}